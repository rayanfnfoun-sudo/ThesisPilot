/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  BookOpen, 
  Target, 
  Building2, 
  Globe2, 
  Lightbulb, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles, 
  Loader2, 
  CheckCircle2, 
  FileText, 
  ListChecks, 
  RefreshCw,
  ChevronDown,
  ChevronUp,
  GraduationCap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface ResearchResult {
  title: string;
  problemStatement: string;
  hypotheses: string[];
  researchPlan: {
    chapter: string;
    sections: {
      title: string;
      subsections: string[];
    }[];
  }[];
  practicalSteps: string[];
  titleEvaluation: {
    score: number;
    feedback: string;
    suggestions: string[];
  };
}

const STEPS = [
  { id: 'specialization', label: 'التخصص الأكاديمي', icon: GraduationCap, placeholder: 'مثال: العلوم الاقتصادية، الحقوق، علوم الإعلام والاتصال...' },
  { id: 'field', label: 'المجال الموضوعي للبحث', icon: BookOpen, placeholder: 'مثال: التسويق الرقمي، القانون الجنائي، تطبيقات الذكاء الاصطناعي...' },
  { id: 'studyType', label: 'المنهجية المقترحة', icon: ListChecks, options: ['دراسة نظرية', 'دراسة تطبيقية', 'دراسة وصفية تحليلية'] },
  { id: 'institution', label: 'ميدان الدراسة (المؤسسة/القطاع)', icon: Building2, placeholder: 'مثال: المؤسسات الناشئة، قطاع الخدمات الصحية، البنوك التجارية...' },
  { id: 'environment', label: 'النطاق الجغرافي أو الاقتصادي', icon: Globe2, placeholder: 'مثال: السوق المحلية، منطقة الشرق الأوسط، الاقتصاد الكلي...' },
  { id: 'goal', label: 'الغايات والأهداف البحثية', icon: Target, placeholder: 'ما هي النتائج المرجوة أو المساهمة العلمية التي تسعى لتحقيقها؟' },
];

export default function App() {
  const [step, setStep] = useState(-1); // -1 for landing page
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ResearchResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expandedChapters, setExpandedChapters] = useState<number[]>([]);

  const handleStart = () => setStep(0);

  const handleNext = () => {
    if (step < STEPS.length - 1) {
      setStep(step + 1);
    } else {
      generateResearch();
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  const updateFormData = (value: string) => {
    setFormData(prev => ({ ...prev, [STEPS[step].id]: value }));
  };

  const generateResearch = async () => {
    setLoading(true);
    setError(null);
    try {
      const prompt = `
        بصفتك خبيراً أكاديمياً متخصصاً في منهجية البحث العلمي، يرجى تقديم مقترح بحثي متكامل لمذكرة تخرج بناءً على المعطيات التالية:
        
        المعطيات البحثية:
        - التخصص الأكاديمي: ${formData.specialization}
        - المجال الموضوعي: ${formData.field}
        - المنهجية المقترحة: ${formData.studyType}
        - ميدان الدراسة: ${formData.institution}
        - النطاق الجغرافي/الاقتصادي: ${formData.environment}
        - الغايات البحثية: ${formData.goal}

        المطلوب صياغة ما يلي بأسلوب أكاديمي رصين وباللغة العربية الفصحى:
        1. عنوان أكاديمي دقيق (قابل للدراسة والقياس).
        2. صياغة إشكالية البحث (طرح المشكلة المركزية بوضوح).
        3. فرضيات الدراسة (صياغة علمية تعكس العلاقة بين المتغيرات).
        4. هيكل الأطروحة (خطة بحث تتضمن فصولاً ومباحث ومطالب متسلسلة منطقياً).
        5. خارطة طريق إجرائية (خطوات عملية لتنفيذ البحث).
        6. تقييم للعنوان المقترح (مدى دقته، شموله، ووضوحه) مع تقديم مقترحات بديلة إذا كان العنوان واسعاً جداً أو غامضاً.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "العنوان الأكاديمي المقترح" },
              problemStatement: { type: Type.STRING, description: "إشكالية البحث" },
              hypotheses: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "فرضيات الدراسة"
              },
              researchPlan: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    chapter: { type: Type.STRING, description: "عنوان الفصل" },
                    sections: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          title: { type: Type.STRING, description: "عنوان المبحث" },
                          subsections: { 
                            type: Type.ARRAY, 
                            items: { type: Type.STRING },
                            description: "المطالب"
                          }
                        }
                      }
                    }
                  }
                }
              },
              practicalSteps: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "خطوات عملية للإنجاز"
              },
              titleEvaluation: {
                type: Type.OBJECT,
                properties: {
                  score: { type: Type.NUMBER, description: "درجة دقة العنوان من 1 إلى 10" },
                  feedback: { type: Type.STRING, description: "تحليل نقدي للعنوان" },
                  suggestions: { 
                    type: Type.ARRAY, 
                    items: { type: Type.STRING },
                    description: "عناوين بديلة محسنة"
                  }
                },
                required: ["score", "feedback", "suggestions"]
              }
            },
            required: ["title", "problemStatement", "hypotheses", "researchPlan", "practicalSteps", "titleEvaluation"]
          }
        }
      });

      const data = JSON.parse(response.text);
      setResult(data);
      setExpandedChapters([0]); // Auto-expand first chapter
      setStep(STEPS.length); // Move to result view
    } catch (err) {
      console.error(err);
      setError("حدث خطأ أثناء توليد الخطة. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  const toggleChapter = (index: number) => {
    setExpandedChapters(prev => 
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  const reset = () => {
    setStep(-1);
    setFormData({});
    setResult(null);
    setExpandedChapters([]);
  };

  const [refineQuery, setRefineQuery] = useState('');
  const [isRefining, setIsRefining] = useState(false);

  const handleRefine = async () => {
    if (!refineQuery.trim() || !result) return;
    setIsRefining(true);
    setError(null);
    try {
      const prompt = `
        بناءً على خطة البحث السابقة:
        العنوان: ${result.title}
        الإشكالية: ${result.problemStatement}
        
        طلب الطالب التعديل التالي: "${refineQuery}"
        
        يرجى تحديث الخطة (العنوان، الإشكالية، الفرضيات، الخطة، الخطوات، وتقييم العنوان) بناءً على هذا الطلب مع الحفاظ على التنسيق الأكاديمي.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              problemStatement: { type: Type.STRING },
              hypotheses: { type: Type.ARRAY, items: { type: Type.STRING } },
              researchPlan: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    chapter: { type: Type.STRING },
                    sections: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          title: { type: Type.STRING },
                          subsections: { type: Type.ARRAY, items: { type: Type.STRING } }
                        }
                      }
                    }
                  }
                }
              },
              practicalSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
              titleEvaluation: {
                type: Type.OBJECT,
                properties: {
                  score: { type: Type.NUMBER },
                  feedback: { type: Type.STRING },
                  suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ["score", "feedback", "suggestions"]
              }
            },
            required: ["title", "problemStatement", "hypotheses", "researchPlan", "practicalSteps", "titleEvaluation"]
          }
        }
      });

      const data = JSON.parse(response.text);
      setResult(data);
      setRefineQuery('');
    } catch (err) {
      console.error(err);
      setError("حدث خطأ أثناء تعديل الخطة.");
    } finally {
      setIsRefining(false);
    }
  };

  const currentStepData = STEPS[step];

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-emerald-100" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-gray-900">ThesisPilot</h1>
              <p className="text-xs text-gray-500 font-medium">مساعدك الذكي في البحث الأكاديمي</p>
            </div>
          </div>
          {result && (
            <button 
              onClick={reset}
              className="text-sm font-medium text-emerald-600 hover:text-emerald-700 flex items-center gap-2 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              بدء بحث جديد
            </button>
          )}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {step === -1 ? (
            <motion.div
              key="landing"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center space-y-12 py-12"
            >
              <div className="space-y-6">
                <motion.div 
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="w-24 h-24 bg-emerald-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-emerald-200 mx-auto"
                >
                  <GraduationCap className="text-white w-12 h-12" />
                </motion.div>
                <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-tight">
                  منصتكم الذكية لـ <br />
                  <span className="text-emerald-600">هيكلة البحوث الأكاديمية</span>
                </h2>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
                  نحو صياغة علمية دقيقة لمذكرات التخرج وتقارير التربص، مبنية على رؤيتكم وأهدافكم البحثية بأسلوب أكاديمي رصين.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
                {[
                  { title: 'تحليل منهجي', desc: 'تأطير دقيق للتخصص والأهداف', icon: Lightbulb },
                  { title: 'هيكلة أكاديمية', desc: 'بناء فصول ومباحث وفق المعايير العلمية', icon: BookOpen },
                  { title: 'تطوير مستمر', desc: 'إمكانية مراجعة وتدقيق المقترحات', icon: RefreshCw },
                ].map((feature, i) => (
                  <div key={i} className="p-6 bg-white rounded-2xl border border-gray-100 shadow-sm">
                    <feature.icon className="w-8 h-8 text-emerald-600 mb-4 mx-auto" />
                    <h4 className="font-bold text-gray-900 mb-2">{feature.title}</h4>
                    <p className="text-sm text-gray-500">{feature.desc}</p>
                  </div>
                ))}
              </div>

              <button
                onClick={handleStart}
                className="group relative inline-flex items-center gap-3 px-10 py-5 bg-emerald-600 text-white rounded-2xl font-bold text-xl shadow-2xl shadow-emerald-200 hover:bg-emerald-700 transition-all hover:-translate-y-1 active:translate-y-0"
              >
                ابدأ الآن مجاناً
                <ArrowLeft className="w-6 h-6 group-hover:-translate-x-1 transition-transform" />
              </button>
            </motion.div>
          ) : step < STEPS.length ? (
            <motion.div
              key="questionnaire"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* Progress Bar */}
              <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <motion.div 
                  className="bg-emerald-600 h-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${((step + 1) / STEPS.length) * 100}%` }}
                />
              </div>

              <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-gray-100">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center">
                    <currentStepData.icon className="text-emerald-600 w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">الخطوة {step + 1} من {STEPS.length}</span>
                    <h2 className="text-2xl font-bold text-gray-900">{currentStepData.label}</h2>
                  </div>
                </div>

                <div className="space-y-6">
                  {currentStepData.options ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {currentStepData.options.map((option) => (
                        <button
                          key={option}
                          onClick={() => updateFormData(option)}
                          className={`p-4 rounded-2xl border-2 text-right transition-all duration-200 ${
                            formData[currentStepData.id] === option
                              ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                              : 'border-gray-100 hover:border-emerald-200 hover:bg-gray-50'
                          }`}
                        >
                          <span className="font-medium">{option}</span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <textarea
                      value={formData[currentStepData.id] || ''}
                      onChange={(e) => updateFormData(e.target.value)}
                      placeholder={currentStepData.placeholder}
                      className="w-full p-6 rounded-2xl border-2 border-gray-100 focus:border-emerald-600 focus:ring-0 transition-all min-h-[150px] text-lg resize-none bg-gray-50/50"
                    />
                  )}
                </div>

                <div className="flex items-center justify-between mt-12">
                  <button
                    onClick={handleBack}
                    disabled={step === 0}
                    className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
                      step === 0 ? 'opacity-0 pointer-events-none' : 'text-gray-500 hover:text-gray-900'
                    }`}
                  >
                    <ArrowRight className="w-5 h-5" />
                    السابق
                  </button>
                  <button
                    onClick={handleNext}
                    disabled={!formData[currentStepData.id]}
                    className={`flex items-center gap-2 px-8 py-3 rounded-xl font-bold shadow-lg transition-all ${
                      formData[currentStepData.id]
                        ? 'bg-emerald-600 text-white shadow-emerald-200 hover:bg-emerald-700 hover:-translate-y-0.5 active:translate-y-0'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
                    }`}
                  >
                    {step === STEPS.length - 1 ? 'توليد الخطة' : 'التالي'}
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ) : loading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-20 space-y-8"
            >
              <div className="relative">
                <Loader2 className="w-16 h-16 text-emerald-600 animate-spin" />
                <Sparkles className="absolute -top-2 -right-2 text-emerald-400 w-6 h-6 animate-pulse" />
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-2xl font-bold text-gray-900">جاري معالجة البيانات وبناء الهيكل الأكاديمي...</h3>
                <p className="text-gray-500 max-w-md mx-auto">
                  يعمل المحرك الذكي الآن على صياغة مقترح بحثي متكامل يتوافق مع المعايير العلمية المتبعة.
                </p>
              </div>
            </motion.div>
          ) : result ? (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-10"
            >
              {/* Refinement Section */}
              <section className="bg-emerald-50 rounded-3xl p-8 border border-emerald-100">
                <div className="flex items-center gap-3 mb-4">
                  <Sparkles className="text-emerald-600 w-6 h-6" />
                  <h3 className="text-xl font-bold text-emerald-900">تطوير وتعديل المقترح الأكاديمي</h3>
                </div>
                <p className="text-emerald-800/70 text-sm mb-6">
                  يمكنكم طلب تعديلات محددة، مثل: "توجيه البحث نحو الجانب القانوني" أو "إضافة محور يتعلق بالتحليل الإحصائي".
                </p>
                <div className="flex gap-3">
                  <input 
                    type="text"
                    value={refineQuery}
                    onChange={(e) => setRefineQuery(e.target.value)}
                    placeholder="اكتب طلب التعديل هنا..."
                    className="flex-1 p-4 rounded-xl border-2 border-emerald-200 focus:border-emerald-600 focus:ring-0 bg-white transition-all outline-none"
                    onKeyDown={(e) => e.key === 'Enter' && handleRefine()}
                  />
                  <button 
                    onClick={handleRefine}
                    disabled={isRefining || !refineQuery.trim()}
                    className="px-6 py-4 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all disabled:opacity-50 flex items-center gap-2"
                  >
                    {isRefining ? <Loader2 className="w-5 h-5 animate-spin" /> : <RefreshCw className="w-5 h-5" />}
                    تعديل
                  </button>
                </div>
              </section>

              {/* Title Section */}
              <section className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-gray-100 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-2 h-full bg-emerald-600" />
                <div className="flex items-start justify-between mb-6">
                  <div className="bg-emerald-50 text-emerald-700 px-4 py-1 rounded-full text-sm font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    العنوان الأكاديمي المقترح
                  </div>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight mb-6">
                  {result.title}
                </h2>

                {/* Title Evaluation */}
                <div className="mb-8 p-6 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-emerald-800 font-bold">
                      <Sparkles className="w-5 h-5" />
                      تحليل جودة العنوان
                    </div>
                    <div className="flex items-center gap-1">
                      {[...Array(10)].map((_, i) => (
                        <div 
                          key={i} 
                          className={`w-2 h-4 rounded-full ${i < result.titleEvaluation.score ? 'bg-emerald-500' : 'bg-gray-200'}`}
                        />
                      ))}
                      <span className="mr-2 text-sm font-bold text-emerald-700">{result.titleEvaluation.score}/10</span>
                    </div>
                  </div>
                  <p className="text-gray-700 text-sm mb-4 leading-relaxed">
                    {result.titleEvaluation.feedback}
                  </p>
                  {result.titleEvaluation.suggestions.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-xs font-bold text-emerald-800 uppercase tracking-wider">مقترحات بديلة لتحسين الدقة:</p>
                      <div className="flex flex-wrap gap-2">
                        {result.titleEvaluation.suggestions.map((suggestion, i) => (
                          <button 
                            key={i}
                            onClick={() => {
                              setRefineQuery(`استخدم هذا العنوان بدلاً من الحالي: ${suggestion}`);
                              handleRefine();
                            }}
                            className="text-xs bg-white border border-emerald-200 text-emerald-700 px-3 py-1.5 rounded-lg hover:bg-emerald-600 hover:text-white transition-all text-right"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                  <div className="flex items-center gap-2 text-emerald-700 font-bold mb-3">
                    <FileText className="w-5 h-5" />
                    الصياغة الإشكالية للبحث
                  </div>
                  <p className="text-gray-700 leading-relaxed text-lg">
                    {result.problemStatement}
                  </p>
                </div>
              </section>

              {/* Hypotheses */}
              <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
                  <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                    <Lightbulb className="text-amber-500 w-6 h-6" />
                    الفرضيات العلمية المقترحة
                  </h3>
                  <ul className="space-y-4">
                    {result.hypotheses.map((h, i) => (
                      <li key={i} className="flex gap-4 items-start">
                        <span className="flex-shrink-0 w-6 h-6 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center text-xs font-bold mt-1">
                          {i + 1}
                        </span>
                        <p className="text-gray-700 leading-relaxed">{h}</p>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-emerald-900 rounded-3xl p-8 shadow-sm text-white">
                  <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
                    <ListChecks className="text-emerald-400 w-6 h-6" />
                    خارطة الطريق الإجرائية
                  </h3>
                  <ul className="space-y-4">
                    {result.practicalSteps.map((step, i) => (
                      <li key={i} className="flex gap-4 items-start">
                        <div className="flex-shrink-0 w-6 h-6 border border-emerald-700 rounded-full flex items-center justify-center text-xs font-bold mt-1">
                          {i + 1}
                        </div>
                        <p className="text-emerald-50/80 text-sm leading-relaxed">{step}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              </section>

              {/* Research Plan */}
              <section className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-8 border-b border-gray-100 flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                    <BookOpen className="text-emerald-600 w-7 h-7" />
                    هيكل الأطروحة/المذكرة المقترح
                  </h3>
                </div>
                <div className="divide-y divide-gray-100">
                  {result.researchPlan.map((chapter, cIdx) => (
                    <div key={cIdx} className="group">
                      <button 
                        onClick={() => toggleChapter(cIdx)}
                        className="w-full p-8 flex items-center justify-between hover:bg-gray-50 transition-colors text-right"
                      >
                        <div className="flex items-center gap-6">
                          <span className="text-4xl font-black text-gray-100 group-hover:text-emerald-100 transition-colors">
                            {String(cIdx + 1).padStart(2, '0')}
                          </span>
                          <h4 className="text-xl font-bold text-gray-900">{chapter.chapter}</h4>
                        </div>
                        {expandedChapters.includes(cIdx) ? (
                          <ChevronUp className="text-gray-400 w-6 h-6" />
                        ) : (
                          <ChevronDown className="text-gray-400 w-6 h-6" />
                        )}
                      </button>
                      
                      <AnimatePresence>
                        {expandedChapters.includes(cIdx) && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden bg-gray-50/50"
                          >
                            <div className="p-8 pt-0 space-y-8">
                              {chapter.sections.map((section, sIdx) => (
                                <div key={sIdx} className="space-y-4">
                                  <h5 className="font-bold text-emerald-800 flex items-center gap-2">
                                    <div className="w-2 h-2 bg-emerald-600 rounded-full" />
                                    {section.title}
                                  </h5>
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pr-4">
                                    {section.subsections.map((sub, subIdx) => (
                                      <div key={subIdx} className="p-3 bg-white rounded-xl border border-gray-100 text-sm text-gray-600 shadow-sm">
                                        {sub}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </div>
              </section>

              {/* Footer Actions */}
              <div className="flex flex-col md:flex-row items-center justify-center gap-4 py-10">
                <button 
                  onClick={() => window.print()}
                  className="w-full md:w-auto px-8 py-4 bg-gray-900 text-white rounded-2xl font-bold shadow-xl hover:bg-black transition-all flex items-center justify-center gap-2"
                >
                  <FileText className="w-5 h-5" />
                  تحميل الخطة (PDF)
                </button>
                <button 
                  onClick={reset}
                  className="w-full md:w-auto px-8 py-4 bg-white text-gray-900 border-2 border-gray-100 rounded-2xl font-bold hover:bg-gray-50 transition-all flex items-center justify-center gap-2"
                >
                  <RefreshCw className="w-5 h-5" />
                  تعديل المعلومات والبدء من جديد
                </button>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </main>

      {/* Error Toast */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-red-600 text-white px-6 py-3 rounded-xl shadow-2xl z-50 flex items-center gap-3"
          >
            <span className="font-medium">{error}</span>
            <button onClick={() => setError(null)} className="hover:opacity-70">×</button>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="max-w-4xl mx-auto px-6 py-12 text-center border-t border-gray-100">
        <p className="text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} ThesisPilot. جميع الحقوق محفوظة.
          <br />
          منصة مخصصة لدعم التميز البحثي وتطوير المهارات الأكاديمية للطلبة.
        </p>
      </footer>
    </div>
  );
}
